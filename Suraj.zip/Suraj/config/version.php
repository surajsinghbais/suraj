<?php
return array (
  'app_version' => 'v4.6.3',
  'full_app_version' => 'v4.6.3 - build 3866-g3de1de9dc',
  'build_version' => '3866',
  'prerelease_version' => '',
  'hash_version' => 'g3de1de9dc',
  'full_hash' => 'v4.6.2-19-g3de1de9dc',
  'branch' => 'master',
);